var original_metadata_container;
var original_date_time_temp_container;

var clockTimer;
var metadataTimer;
var weatherTimer;
var transitionTimer;
var settingsTimer;

var oldData;
var oldMedia = true;
var init = true;
var updating = false;

var layoutPos = 0;

// Base URL for API calls - will be set on init
var apiBaseUrl = "";

// Settings object - loaded from server
var displaySettings = {
    timeFormat: "12 Hour",
    showTime: true,
    showDate: true,
    showWeather: true,
    showMedia: true,
    displayMode: "Normal",
    fadeInterval: 60,
    backgroundColor: "#000000",
    textColor: "#FFFFFF",
    mediaPollInterval: 3000,
    settingsPollInterval: 60000
};

function getApiBaseUrl() {
    // The page URL structure is: http://controller:PORT/ROOMID
    // We need to extract the base (http://controller:PORT/)
    var url = window.location.href;
    
    // Remove any trailing path segments to get base
    // URL format: http://ip:port/roomid or http://ip:port/roomid/
    var parts = url.split('/');
    // parts[0] = http:, parts[1] = "", parts[2] = ip:port, parts[3] = roomid
    if (parts.length >= 3) {
        apiBaseUrl = parts[0] + '//' + parts[2] + '/';
    } else {
        apiBaseUrl = url;
        if (!apiBaseUrl.endsWith('/')) {
            apiBaseUrl += '/';
        }
    }
    console.log("API Base URL: " + apiBaseUrl);
    return apiBaseUrl;
}

function loadSettings() {
    try {
        var settingsUrl = apiBaseUrl + "settings";
        console.log("Loading settings from: " + settingsUrl);
        var settingsData = urlCall(settingsUrl);
        console.log("Settings response: " + settingsData);
        
        if (settingsData && settingsData !== "" && settingsData !== "{}") {
            var newSettings = parseJSON(settingsData);
            
            // Check if settings changed
            var settingsChanged = (
                displaySettings.timeFormat !== newSettings.timeFormat ||
                displaySettings.showTime !== newSettings.showTime ||
                displaySettings.showDate !== newSettings.showDate ||
                displaySettings.showWeather !== newSettings.showWeather ||
                displaySettings.showMedia !== newSettings.showMedia ||
                displaySettings.backgroundColor !== newSettings.backgroundColor ||
                displaySettings.textColor !== newSettings.textColor
            );
            
            // Check if poll intervals changed
            var mediaPollChanged = (displaySettings.mediaPollInterval !== newSettings.mediaPollInterval);
            var settingsPollChanged = (displaySettings.settingsPollInterval !== newSettings.settingsPollInterval);
            
            displaySettings = newSettings;
            console.log("Settings loaded: " + JSON.stringify(displaySettings));
            
            if (settingsChanged) {
                console.log("Settings changed, applying...");
                applySettings();
            }
            
            // Restart metadata timer if poll interval changed
            if (mediaPollChanged && metadataTimer) {
                console.log("Media poll interval changed to: " + displaySettings.mediaPollInterval + "ms");
                clearInterval(metadataTimer);
                metadataTimer = setInterval(function() { 
                    if (displaySettings.showMedia) {
                        updateMetadata(); 
                    }
                }, displaySettings.mediaPollInterval);
            }
            
            // Restart settings timer if poll interval changed
            if (settingsPollChanged && settingsTimer) {
                console.log("Settings poll interval changed to: " + displaySettings.settingsPollInterval + "ms");
                clearInterval(settingsTimer);
                settingsTimer = setInterval(function() { loadSettings(); }, displaySettings.settingsPollInterval);
            }
        }
    } catch (e) {
        console.log("Error loading settings: " + e);
    }
}

function applySettings() {
    console.log("Applying settings: " + JSON.stringify(displaySettings));
    
    // Apply background color
    document.body.style.backgroundColor = displaySettings.backgroundColor;
    
    // Apply text color to all text elements
    var textElements = document.querySelectorAll('.text');
    for (var i = 0; i < textElements.length; i++) {
        textElements[i].style.color = displaySettings.textColor;
    }
    
    // Apply widget visibility
    var timeContainer = document.getElementById("time");
    var dateContainer = document.getElementById("date");
    var tempContainer = document.getElementById("temp");
    var metadataContainer = document.getElementById("metadata-container");
    var dateTimeTempContainer = document.getElementById("date-time-temp-container");
    
    if (timeContainer) {
        timeContainer.style.display = displaySettings.showTime ? "flex" : "none";
    }
    
    if (dateContainer) {
        dateContainer.style.display = displaySettings.showDate ? "flex" : "none";
    }
    
    if (tempContainer) {
        tempContainer.style.display = displaySettings.showWeather ? "flex" : "none";
    }
    
    // Handle media visibility - this affects the layout
    if (!displaySettings.showMedia && metadataContainer) {
        metadataContainer.style.visibility = "hidden";
        metadataContainer.style.width = "0";
        metadataContainer.style.marginRight = "0";
        // Expand the date-time-temp container
        if (dateTimeTempContainer) {
            dateTimeTempContainer.style.width = "100vw";
            dateTimeTempContainer.style.marginLeft = "0";
        }
    } else if (displaySettings.showMedia && metadataContainer) {
        // Restore normal layout if media is enabled
        metadataContainer.style.visibility = "";
        metadataContainer.style.width = "";
        metadataContainer.style.marginRight = "";
        if (dateTimeTempContainer) {
            dateTimeTempContainer.style.width = "";
            dateTimeTempContainer.style.marginLeft = "";
        }
    }
    
    // Update clock display for time format
    updateClock();
}

function updateClock() {
 
    var date = new Date()
    
    var hours = date.getHours();
    var minutes = date.getMinutes();
    var days = ['SUN', 'MON', 'TUE', 'WED', 'THU', 'FRI', 'SAT'];
    var dayName = days[date.getDay()];
    var dayNum = date.getDate();
    var months = ['JAN', 'FEB', 'MAR', 'APR', 'MAY', 'JUN', 'JUL', 'AUG', 'SEP', 'OCT', 'NOV', 'DEC'];
    var monthName = months[date.getMonth()];
    var monthNum = date.getMonth() + 1; // 0-indexed
    var year = date.getFullYear() % 100; // Get last 2 digits
    
    var clock;
    var ampmElement = document.getElementById("ampm");
    
    if (displaySettings.timeFormat === "24 Hour") {
        // 24-hour format
        var hoursStr = hours < 10 ? '0' + hours : hours;
        minutes = minutes < 10 ? '0' + minutes : minutes;
        clock = hoursStr + ':' + minutes;
        
        // Hide AM/PM indicator in 24-hour mode
        if (ampmElement) {
            ampmElement.style.display = "none";
        }
    } else {
        // 12-hour format
        var ampm = hours >= 12 ? 'PM' : 'AM';
        hours = hours % 12;
        hours = hours ? hours : 12; // the hour '0' should be '12'
        minutes = minutes < 10 ? '0' + minutes : minutes;
        clock = hours + ':' + minutes;
        
        // Show AM/PM indicator
        if (ampmElement) {
            ampmElement.style.display = "";
            ampmElement.innerHTML = ampm;
        }
    }
    
    var clockElement = document.getElementById("clock");
    if (clockElement) {
        clockElement.innerHTML = clock;
    }
    
    var dayofweekElement = document.getElementById("dayofweek");
    var dayElement = document.getElementById("day");
    var monthElement = document.getElementById("month");
    
    // Check if Big Clock mode - format date as M/DD/YY
    if (displaySettings.displayMode === "Big Clock") {
        if (dayElement) {
            dayElement.innerHTML = monthNum + "/" + dayNum + "/" + year;
        }
        if (dayofweekElement) {
            dayofweekElement.style.display = "none";
        }
        if (monthElement) {
            monthElement.style.display = "none";
        }
    } else {
        // Normal mode - show separate elements
        if (dayofweekElement) {
            dayofweekElement.innerHTML = dayName;
            dayofweekElement.style.display = "";
        }
        if (dayElement) {
            dayElement.innerHTML = dayNum;
        }
        if (monthElement) {
            monthElement.innerHTML = monthName;
            monthElement.style.display = "";
        }
    }
    
    var monthElement = document.getElementById("month");
    if (monthElement) {
        monthElement.innerHTML = monthName;
    }
}

function updateMetadata() {
    // Skip if media is disabled in settings
    if (!displaySettings.showMedia) {
        return;
    }
    
    var url = window.location.href;
    var data = urlCall(url+"/json")
    var jsonData = parseJSON(data);
    var media;
    var metadata_container = document.getElementById("metadata-container");
    var metadata_visibility = metadata_container ? window.getComputedStyle(metadata_container).visibility : "hidden";
    
    if (jsonData.title == null && jsonData.artist == null && jsonData.album == null && jsonData.img == null && jsonData.devicename == null) {
        media = false
    } else if (data != "{}" && metadata_visibility == "hidden") {
        if (updating == false){
            arrangeContent(true,true,true,true)
            updateWeather()
        }
    } else if (data != oldData) {
        
        // Determine which image to use
        var imgSrc = "";
        if (jsonData.img && jsonData.img !== "") {
            imgSrc = jsonData.img;
        } else if (jsonData.deviceIcon && jsonData.deviceIcon !== "") {
            imgSrc = jsonData.deviceIcon;
        } else if (jsonData.deviceIconFallback && jsonData.deviceIconFallback !== "") {
            imgSrc = jsonData.deviceIconFallback;
        } else if (jsonData.imgFallback && jsonData.imgFallback !== "") {
            imgSrc = jsonData.imgFallback;
        } else {
            imgSrc = "png/default_cover_art.png";
        }

        if (!jsonData.title && !jsonData.artist && !jsonData.album) {
            document.getElementById("title").innerHTML = jsonData.devicename || "";
            document.getElementById("artist").innerHTML = "";
            document.getElementById("album").innerHTML = "";
        } else {
            document.getElementById("title").innerHTML = jsonData.title || "";
            document.getElementById("artist").innerHTML = jsonData.artist || "";
            document.getElementById("album").innerHTML = jsonData.album || "";
        }

        var artElement = document.getElementById("art");
        artElement.src = imgSrc;
        
        // Add error handler to try fallback images
        artElement.onerror = function() {
            if (jsonData.imgFallback && this.src !== jsonData.imgFallback) {
                this.src = jsonData.imgFallback;
            } else if (jsonData.deviceIcon && this.src !== jsonData.deviceIcon) {
                this.src = jsonData.deviceIcon;
            } else if (jsonData.deviceIconFallback && this.src !== jsonData.deviceIconFallback) {
                this.src = jsonData.deviceIconFallback;
            } else {
                this.src = "png/default_cover_art.png";
            }
        };
        
        media = true
        oldData = data
    }
    
    if (media == false && metadata_visibility != "hidden") {
        if (updating == false){
            arrangeContent(true,true,true,false)
            oldData = ""
        }
    }
    
    oldMedia = media
}

function updateWeather() {
    // Skip if weather is disabled in settings
    if (!displaySettings.showWeather) {
        return;
    }
    
    try {
        var projectData = urlCall(apiBaseUrl + "project")
        projectData = parseJSON(projectData)
        
        var lat = projectData.latitude
        var long = projectData.longitude
        
        var weatherUrl1 = "https://api.weather.gov/points/"+lat+","+long
        var weatherData1 = parseJSON(urlCall(weatherUrl1))
        
        var weatherUrl2 = weatherData1.properties.forecastHourly
        var weatherData2 = parseJSON(urlCall(weatherUrl2))
        
        var temp = weatherData2.properties.periods[0].temperature
        
        var scale = "F"
        
        if (projectData.scale == "CELSIUS") {
            temp = (temp -32) * 5/9
            scale = "C"
        }
            
        temp = Math.round(temp)
        
        document.getElementById("temp-num").innerHTML = temp;
        document.getElementById("scale").innerHTML = scale;
    } catch (e) {
        console.log("Error updating weather: " + e);
    }
}

function arrangeContent(time,date,weather,media) {
    var main_container = document.getElementById("main-container");
    var metadata_container = document.getElementById("metadata-container")
    var time_container = document.getElementById("time")
    var date_time_temp_container = document.getElementById("date-time-temp-container")
    var transition_time;
    
    updating = true
    setTimeout(function() { updating = false; }, 3000);
    
    if (init == false) {
        transition_time = 0
        setTimeout(function() { main_container.classList.toggle('fade'); }, 0);
        setTimeout(function() { main_container.classList.toggle('fade'); }, 1700);
        transition_time = 1000
    } else {
        transition_time = 0
    }

    if (media == false || !displaySettings.showMedia) {
        
        setTimeout(function() { metadata_container.innerHTML = ""; }, transition_time);
        setTimeout(function() { metadata_container.appendChild(time_container); }, transition_time);
        setTimeout(function() { swapStyleSheet("css/nomedia.css"); }, transition_time);
        setTimeout(function() { applySettings(); }, transition_time + 100);
        oldData = ""
        
        
    } else {
        oldData = ""
        setTimeout(function() { updateMetadata() }, transition_time+200);
        setTimeout(function() { updateWeather() }, transition_time+200);
        setTimeout(function() { date_time_temp_container.innerHTML = original_date_time_temp_container; }, transition_time);
        setTimeout(function() { metadata_container.innerHTML = original_metadata_container; }, transition_time);
        setTimeout(function() { swapStyleSheet("css/media.css") }, transition_time);
        setTimeout(function() { applySettings(); }, transition_time + 100);
    }
}

function transitionLayout() {
    // Skip layout transition if media is disabled
    if (!displaySettings.showMedia) {
        return;
    }
    
    var main_container = document.getElementById("main-container");
    var metadata_container = document.getElementById("metadata-container");
    var date_time_temp_container = document.getElementById("date-time-temp-container");
    var pos;
    
    function switchPos(){
        if (layoutPos == 0) {
            setTimeout(function() { metadata_container.after(date_time_temp_container); }, 1200);
            pos = 1;
        } else if (layoutPos == 1) {
            setTimeout(function() { date_time_temp_container.after(metadata_container); }, 1200);
            pos = 0;
        }
    }
    setTimeout(function() { main_container.classList.toggle('fade'); }, 0);
    switchPos();
    setTimeout(function() { main_container.classList.toggle('fade'); }, 1500);
    setTimeout(function() { applySettings(); }, 1600);
    
    layoutPos = pos;
}

function urlCall(url) {
    try {
        var xmlHttp = new XMLHttpRequest();
        xmlHttp.open("GET", url, false); // false for synchronous request
        xmlHttp.send(null);
        return xmlHttp.responseText;
    } catch (e) {
        console.log("Error in urlCall to " + url + ": " + e);
        return "{}";
    }
}

function parseJSON(json) {
    try {
        return JSON.parse(json);
    } catch (e) {
        console.log("Error parsing JSON: " + e);
        return {};
    }
}

function swapStyleSheet(sheet) {
    document.getElementById("layout-stylesheet").setAttribute("href", sheet);  
}

function populateMetadata() {
    // Determine the API base URL first
    getApiBaseUrl();
    
    original_metadata_container = document.getElementById("metadata-container").innerHTML;
    original_date_time_temp_container = document.getElementById("date-time-temp-container").innerHTML;
    
    // Load settings first - this is synchronous so displaySettings will be updated
    loadSettings();
    applySettings();
    
    updateClock();
    
    // Check display mode
    if (displaySettings.displayMode === "Big Clock") {
        // Big Clock mode - just show centered clock with fade effect
        console.log("Big Clock mode enabled");
        swapStyleSheet("css/bigclock.css");
        
        // Add fade cycle class for burn-in prevention
        var mainContainer = document.getElementById("main-container");
        if (mainContainer) {
            mainContainer.classList.add("fade-cycle");
            
            // Apply dynamic fade interval
            var fadeSeconds = displaySettings.fadeInterval || 60;
            mainContainer.style.animationDuration = fadeSeconds + "s";
        }
        
        // Only update weather if enabled
        if (displaySettings.showWeather) {
            updateWeather();
        }
        
        // Update clock every second
        clockTimer = setInterval(function() { updateClock(); }, 1000);
        
        // Update weather every 5 minutes
        weatherTimer = setInterval(function() { 
            if (displaySettings.showWeather) {
                updateWeather(); 
            }
        }, 300000);
        
        // Check for settings changes
        var settingsPollMs = displaySettings.settingsPollInterval || 60000;
        settingsTimer = setInterval(function() { loadSettings(); }, settingsPollMs);
        
        setTimeout(function() { init = false; }, 3000);
        return;
    }
    
    // Normal mode
    if (displaySettings.showMedia) {
        updateMetadata();
    }
    
    if (displaySettings.showWeather) {
        updateWeather();
    }
    
    // Update clock every second (local only, no server call)
    clockTimer = setInterval(function() { updateClock(); }, 1000);
    
    // Check for media changes based on configured interval (default 3 seconds)
    var mediaPollMs = displaySettings.mediaPollInterval || 3000;
    console.log("Starting media timer with interval: " + mediaPollMs + "ms");
    metadataTimer = setInterval(function() { 
        if (displaySettings.showMedia) {
            updateMetadata(); 
        }
    }, mediaPollMs);
    
    // Update weather every 5 minutes
    weatherTimer = setInterval(function() { 
        if (displaySettings.showWeather) {
            updateWeather(); 
        }
    }, 300000);
    
    // Transition layout every 5 minutes
    transitionTimer = setInterval(function() { 
        if (displaySettings.showMedia) {
            transitionLayout(); 
        }
    }, 300000);
    
    // Check for settings changes based on configured interval (default 60 seconds)
    var settingsPollMs = displaySettings.settingsPollInterval || 60000;
    console.log("Starting settings timer with interval: " + settingsPollMs + "ms");
    settingsTimer = setInterval(function() { loadSettings(); }, settingsPollMs);
    
    setTimeout(function() { init = false; }, 3000);
}
